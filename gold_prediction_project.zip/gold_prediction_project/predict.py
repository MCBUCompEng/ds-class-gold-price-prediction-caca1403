from Model.functions import load_and_preprocess_data, train_model, evaluate_model

def main():
    path = "DataSet/gram_gold_10yrs.csv"

    print("\n--- ANALİZ 1: HAM FİYAT TAHMİNİ (Trend Takibi) ---")
    X, y, prices = load_and_preprocess_data(path, mode='price')
    split = int(len(X) * 0.8)
    model_p = train_model(X[:split], y[:split], lr=0.1)
    mse_p, r2_p = evaluate_model(model_p, X[split:], y[split:])
    print(f"R2 Skoru: {r2_p:.4f} (Yüksek olması normaldir, trendi takip eder.)")
    
    # 5 Günlük Fiyat Tahmini
    curr = [prices[-1], prices[-2], prices[-3]]
    print("Sonraki 5 Gün Fiyat Projeksiyonu:")
    for i in range(1, 6):
        p = model_p.predict([curr])[0]
        print(f"  Gün {i}: {p:.2f} TL")
        curr = [p, curr[0], curr[1]]

    print("\n--- ANALİZ 2: DEĞİŞİM ORANI TAHMİNİ (Overfitting Kontrolü) ---")
    print("[NOT: Bu bölüm 'Ekstra Özellik Denemesi' olarak eklenmiştir.]")
    X_r, y_r, returns = load_and_preprocess_data(path, mode='return')
    split_r = int(len(X_r) * 0.8)
    model_r = train_model(X_r[:split_r], y_r[:split_r], lr=0.01)
    mse_r, r2_r = evaluate_model(model_r, X_r[split_r:], y_r[split_r:])
    
    print(f"Değişim Oranı R2 Skoru: {r2_r:.4f}")
    
    # Yarınki Yüzdesel Değişim Tahmini
    last_ret = [returns[-1], returns[-2], returns[-3]]
    next_ret = model_r.predict([last_ret])[0]
    direction = "ARTIŞ" if next_ret > 0 else "AZALIŞ"
    print(f"Yarınki Tahmini Hareket: %{next_ret*100:.4f} {direction}")

    print("\n[OLASI PROBLEM DÜŞÜNCESİ İÇİN NOT]: Değişim oranı R2 skorunun düşük çıkması modelin dünün fiyatını")
    print("kopyalamak yerine gerçek piyasa oynaklığını anlamaya çalıştığını gösterir.")

if __name__ == "__main__":
    main()