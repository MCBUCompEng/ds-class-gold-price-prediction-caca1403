import math
import logging
from typing import List, Tuple, Dict, Any

logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')

def load_and_preprocess_data(filepath: str, mode: str = 'price') -> Tuple[List[List[float]], List[float], List[float]]:
    """
    mode='price': Ham fiyat tahmini için veri hazırlar.
    mode='return': Yüzdesel değişim tahmini için veri hazırlar (Overfitting kontrolü).
    """
    prices: List[float] = []
    
    try:
        with open(filepath, 'r', encoding='utf-8', errors='replace') as file:
            lines = file.readlines()[1:]
            for line in lines:
                parts = line.strip().split(";")
                if len(parts) < 3: continue
                raw_close = parts[2].strip().replace(",", ".")
                if raw_close.count('.') > 1:
                    segments = raw_close.split('.')
                    raw_close = "".join(segments[:-1]) + "." + segments[-1]
                try:
                    val = float(raw_close)
                    if val > 0: prices.append(val)
                except ValueError: continue

        if mode == 'price':
            X, y = [], []
            for i in range(3, len(prices)):
                X.append([prices[i-1], prices[i-2], prices[i-3]])
                y.append(prices[i])
            return X, y, prices
        
        elif mode == 'return':
            # Değişim Oranı Hesapla: (Bugün - Dün) / Dün
            returns = [(prices[i] - prices[i-1]) / prices[i-1] for i in range(1, len(prices))]
            X, y = [], []
            for i in range(3, len(returns)):
                X.append([returns[i-1], returns[i-2], returns[i-3]])
                y.append(returns[i])
            return X, y, returns

    except Exception as e:
        logging.error(f"Hata: {e}")
        return [], [], []

class CustomLinearRegression:
    def __init__(self, learning_rate: float = 0.01, epochs: int = 3000) -> None:
        self.lr = learning_rate
        self.epochs = epochs
        self.weights: List[float] = []
        self.bias: float = 0.0
        self.X_mean, self.X_std = [], []
        self.y_mean, self.y_std = 0.0, 1.0

    def _standardize_fit(self, X: List[List[float]], y: List[float]) -> None:
        n = len(X[0])
        self.X_mean = [sum(row[i] for row in X) / len(X) for i in range(n)]
        self.X_std = [math.sqrt(sum((row[i]-self.X_mean[i])**2 for row in X)/len(X)) or 1.0 for i in range(n)]
        self.y_mean = sum(y) / len(y)
        self.y_std = math.sqrt(sum((v-self.y_mean)**2 for v in y)/len(y)) or 1.0

    def _standardize_transform(self, X: List[List[float]]) -> List[List[float]]:
        return [[(row[i]-self.X_mean[i])/self.X_std[i] for i in range(len(row))] for row in X]

    def fit(self, X: List[List[float]], y: List[float]) -> None:
        self._standardize_fit(X, y)
        X_s = self._standardize_transform(X)
        y_s = [(val - self.y_mean) / self.y_std for val in y]
        n_samples, n_features = len(X), len(X[0])
        self.weights = [0.0] * n_features
        self.bias = 0.0

        for _ in range(self.epochs):
            dw, db = [0.0] * n_features, 0.0
            for i in range(n_samples):
                pred = sum(self.weights[j] * X_s[i][j] for j in range(n_features)) + self.bias
                err = pred - y_s[i]
                for j in range(n_features):
                    dw[j] += (2/n_samples) * X_s[i][j] * err
                db += (2/n_samples) * err
            for j in range(n_features):
                self.weights[j] -= self.lr * dw[j]
            self.bias -= self.lr * db

    def predict(self, X: List[List[float]]) -> List[float]:
        X_s = self._standardize_transform(X)
        return [(sum(self.weights[j]*r[j] for j in range(len(r)))+self.bias)*self.y_std + self.y_mean for r in X_s]

def train_model(X_train: List[List[float]], y_train: List[float], lr=0.01) -> CustomLinearRegression:
    model = CustomLinearRegression(learning_rate=lr, epochs=2500)
    model.fit(X_train, y_train)
    return model

def evaluate_model(model: Any, X_test: List[List[float]], y_test: List[float]) -> Tuple[float, float]:
    preds = model.predict(X_test)
    n = len(y_test)
    mse = sum((y_test[i]-preds[i])**2 for i in range(n))/n
    y_m = sum(y_test)/n
    r2 = 1 - (sum((y_test[i]-preds[i])**2 for i in range(n))/sum((v-y_m)**2 for v in y_test))
    return mse, r2